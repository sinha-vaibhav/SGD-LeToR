

print ("LETOR Dataset Linear Regression")
import leteor
print ("Synthetic Dataset")
import synthetic